<?php

namespace LaravelDaily\Invoices\Contracts;

/**
 * Interface PartyContract
 * @package LaravelDaily\Invoices\Contracts
 */
interface PartyContract
{
}
