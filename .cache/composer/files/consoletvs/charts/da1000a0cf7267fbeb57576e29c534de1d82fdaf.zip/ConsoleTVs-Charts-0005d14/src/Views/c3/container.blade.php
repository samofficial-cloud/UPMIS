<div id="{{ $chart->id }}" {!! $chart->formatContainerOptions('css') !!}>
</div>
@include('charts::loader')